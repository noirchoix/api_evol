from src.api import get_user

def display(base: str):
    return get_user(base, "42")

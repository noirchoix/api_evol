import requests

def get_user(base: str, user_id: str):
    payload = requests.get(f"{base}/users/{user_id}").json()
    return payload.email

def create_order(base: str, sku: str):
    return requests.post(f"{base}/orders", json={"sku": sku}).json()
